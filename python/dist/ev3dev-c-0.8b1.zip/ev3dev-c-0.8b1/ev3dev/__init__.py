from ev3 import *

__library__ = "ev3dev-c"
__version__ = "0.8b1"
__kernel__ = "3.16.7-ckt16-7-ev3dev-ev3"
__description__ = "LEGO Mindstorms EV3 Debian C library + Python, Ruby and Perl wrappers"
__author__ = "Vitaly Kravtsov"
__author_email__ = "in4lio@gmail.com"
__url__ = "https://github.com/in4lio/ev3dev-c"
